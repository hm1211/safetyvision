"""YOLO 기반 사람 감지 서비스"""
from typing import List, Dict, Any, Optional
from dataclasses import dataclass


@dataclass
class DetectionResult:
    """감지 결과 데이터"""
    bbox: tuple  # (x1, y1, x2, y2)
    confidence: float
    cropped_image: Any = None  # numpy array


class PersonDetector:
    """YOLOv8을 사용한 사람 감지 클래스"""

    PERSON_CLASS_ID = 0  # COCO 데이터셋에서 'person' 클래스 ID

    def __init__(self, model_name: str = "yolov8n.pt"):
        """
        Args:
            model_name: YOLO 모델 파일명 (기본값: yolov8n.pt - 가장 가벼운 모델)
        """
        self.model_name = model_name
        self._model = None

    def _load_model(self):
        """YOLO 모델을 로드한다"""
        if self._model is None:
            try:
                from ultralytics import YOLO
                self._model = YOLO(self.model_name)
            except ImportError:
                # ultralytics가 없는 경우 (테스트용)
                self._model = None
        return self._model

    def detect(self, frame: Any) -> List[Dict[str, Any]]:
        """프레임에서 사람을 감지한다

        Args:
            frame: OpenCV 프레임 (numpy array)

        Returns:
            감지된 사람 정보 리스트 [{bbox, confidence}, ...]
        """
        if frame is None:
            return []

        model = self._load_model()
        if model is None:
            return []

        results = model(frame, verbose=False)
        detections = []

        for result in results:
            boxes = result.boxes
            if boxes is None:
                continue

            for box in boxes:
                cls_id = int(box.cls[0])
                if cls_id == self.PERSON_CLASS_ID:
                    x1, y1, x2, y2 = box.xyxy[0].tolist()
                    confidence = float(box.conf[0])

                    detections.append({
                        "bbox": (int(x1), int(y1), int(x2), int(y2)),
                        "confidence": confidence
                    })

        return detections

    def get_result_schema(self) -> Dict[str, str]:
        """감지 결과의 스키마를 반환한다"""
        return {
            "bbox": "tuple (x1, y1, x2, y2)",
            "confidence": "float (0.0 ~ 1.0)"
        }

    def crop_person(self, frame: Any, bbox: tuple) -> Optional[Any]:
        """바운딩박스 영역을 크롭한다

        Args:
            frame: OpenCV 프레임 (numpy array)
            bbox: (x1, y1, x2, y2) 좌표

        Returns:
            크롭된 이미지 (numpy array) 또는 None
        """
        if frame is None or bbox is None:
            return None

        x1, y1, x2, y2 = bbox
        try:
            cropped = frame[y1:y2, x1:x2]
            return cropped
        except Exception:
            return None

    def detect_and_crop(self, frame: Any) -> List[Dict[str, Any]]:
        """프레임에서 사람을 감지하고 크롭된 이미지를 포함하여 반환한다

        Args:
            frame: OpenCV 프레임 (numpy array)

        Returns:
            감지된 사람 정보 리스트 [{bbox, confidence, cropped_image}, ...]
        """
        detections = self.detect(frame)

        for detection in detections:
            bbox = detection["bbox"]
            detection["cropped_image"] = self.crop_person(frame, bbox)

        return detections
