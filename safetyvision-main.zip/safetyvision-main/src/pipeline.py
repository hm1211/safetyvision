"""Safety Vision 통합 파이프라인"""
from typing import Dict, Any, List, Optional

from src.video_processor import VideoProcessor
from src.person_detector import PersonDetector
from src.feature_matcher import FeatureMatcher
from src.timestamp_merger import TimestampMerger


class SafetyVisionPipeline:
    """영상에서 특정 특징을 가진 사람을 찾는 통합 파이프라인"""

    def __init__(
        self,
        frame_interval: float = 1.0,
        confidence_threshold: float = 0.5,
        gap_threshold: float = 2.0
    ):
        """
        Args:
            frame_interval: 프레임 추출 간격 (초)
            confidence_threshold: 사람 감지 최소 신뢰도
            gap_threshold: 타임스탬프 병합 시 최대 간격 (초)
        """
        self.frame_interval = frame_interval
        self.confidence_threshold = confidence_threshold
        self.gap_threshold = gap_threshold

        self.video_processor = VideoProcessor()
        self.person_detector = PersonDetector()
        self.feature_matcher = FeatureMatcher()
        self.timestamp_merger = TimestampMerger(gap_threshold=gap_threshold)

    def search(
        self,
        video_path: str,
        feature_description: str,
        progress_callback: Optional[callable] = None
    ) -> Dict[str, Any]:
        """영상에서 특징에 맞는 사람이 등장하는 시간대를 찾는다

        Args:
            video_path: 영상 파일 경로
            feature_description: 찾고자 하는 사람의 특징 설명
            progress_callback: 진행률 콜백 함수 (0.0 ~ 1.0)

        Returns:
            검색 결과 딕셔너리
        """
        result = {
            "success": False,
            "time_ranges": [],
            "formatted_results": [],
            "total_frames_analyzed": 0,
            "persons_detected": 0,
            "matches_found": 0,
            "error": None
        }

        # 1. 영상 정보 확인
        video_info = self.video_processor.get_video_info(video_path)
        if video_info.get("error") or video_info["total_frames"] == 0:
            result["error"] = video_info.get("error", "영상을 열 수 없습니다")
            return result

        # 2. 프레임 추출
        frames = self.video_processor.extract_frames(video_path, self.frame_interval)
        if not frames:
            result["error"] = "프레임을 추출할 수 없습니다"
            return result

        result["total_frames_analyzed"] = len(frames)
        matched_timestamps = []

        # 3. 각 프레임 처리
        for i, frame_data in enumerate(frames):
            timestamp = frame_data["timestamp"]
            frame = frame_data["frame"]

            # 진행률 콜백
            if progress_callback:
                progress_callback((i + 1) / len(frames))

            # 4. YOLO로 사람 감지
            detections = self.person_detector.detect(frame)

            for detection in detections:
                if detection["confidence"] < self.confidence_threshold:
                    continue

                result["persons_detected"] += 1

                # 5. 사람 이미지 크롭
                cropped = self.person_detector.crop_person(frame, detection["bbox"])
                if cropped is None:
                    continue

                # 6. Gemini로 특징 매칭
                match_result = self.feature_matcher.match(cropped, feature_description)

                if match_result["is_match"]:
                    result["matches_found"] += 1
                    matched_timestamps.append(timestamp)
                    break  # 한 프레임에서 매칭되면 다음 프레임으로

        # 7. 타임스탬프 병합
        if matched_timestamps:
            time_ranges = self.timestamp_merger.merge(matched_timestamps)
            result["time_ranges"] = time_ranges
            result["formatted_results"] = self.timestamp_merger.format_results(time_ranges)
            result["success"] = True
        else:
            result["success"] = True  # 검색은 성공했으나 결과 없음
            result["formatted_results"] = ["일치하는 결과를 찾지 못했습니다"]

        return result
