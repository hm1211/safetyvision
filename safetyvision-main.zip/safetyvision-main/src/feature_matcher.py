"""Gemini 기반 특징 매칭 서비스"""
import os
import base64
from typing import Dict, Any, Optional


class FeatureMatcher:
    """Gemini Vision을 사용한 사람 특징 매칭 클래스"""

    def __init__(self, model_name: str = "gemini-2.0-flash"):
        """
        Args:
            model_name: Gemini 모델명
        """
        self.model_name = model_name
        self._client = None

    def _get_client(self):
        """Gemini 클라이언트를 반환한다"""
        if self._client is None:
            try:
                from google import genai

                api_key = os.getenv("GEMINI_API_KEY")
                if api_key:
                    self._client = genai.Client(api_key=api_key)
            except ImportError:
                pass
        return self._client

    def build_prompt(self, feature_description: str) -> str:
        """특징 매칭을 위한 프롬프트를 생성한다

        Args:
            feature_description: 사용자가 입력한 특징 설명

        Returns:
            Gemini에 전달할 프롬프트 문자열
        """
        return f"""이 이미지에 있는 사람이 다음 특징과 일치하는지 판단해주세요.

찾고자 하는 특징: {feature_description}

다음 형식으로만 답변해주세요:
- 일치 여부: YES 또는 NO
- 확신도: 0.0 ~ 1.0 사이의 숫자
- 이유: 간단한 설명

예시:
일치 여부: YES
확신도: 0.85
이유: 빨간색 모자를 착용하고 있음"""

    def _parse_response(self, response_text: str) -> Dict[str, Any]:
        """Gemini 응답을 파싱한다

        Args:
            response_text: Gemini 응답 텍스트

        Returns:
            is_match, confidence, reason을 담은 딕셔너리
        """
        is_match = False
        confidence = 0.0
        reason = ""

        lines = response_text.strip().split("\n")
        for line in lines:
            line = line.strip()
            if "일치 여부:" in line or "일치여부:" in line:
                is_match = "YES" in line.upper()
            elif "확신도:" in line:
                try:
                    conf_str = line.split(":")[-1].strip()
                    confidence = float(conf_str)
                except ValueError:
                    confidence = 0.5 if is_match else 0.0
            elif "이유:" in line:
                reason = line.split(":", 1)[-1].strip()

        return {
            "is_match": is_match,
            "confidence": confidence,
            "reason": reason
        }

    def _encode_image(self, image) -> Optional[str]:
        """이미지를 base64로 인코딩한다

        Args:
            image: numpy array (OpenCV 이미지)

        Returns:
            base64 인코딩된 문자열 또는 None
        """
        if image is None:
            return None

        try:
            import cv2
            _, buffer = cv2.imencode(".jpg", image)
            return base64.b64encode(buffer).decode("utf-8")
        except Exception:
            return None

    def match(self, image, feature_description: str) -> Dict[str, Any]:
        """이미지가 특징 설명과 일치하는지 판단한다

        Args:
            image: 사람 이미지 (numpy array)
            feature_description: 찾고자 하는 특징 설명

        Returns:
            매칭 결과 {is_match, confidence, reason}
        """
        # 이미지가 없으면 매칭 실패
        if image is None:
            return {
                "is_match": False,
                "confidence": 0.0,
                "reason": "이미지가 없습니다"
            }

        client = self._get_client()
        if client is None:
            return {
                "is_match": False,
                "confidence": 0.0,
                "reason": "Gemini 클라이언트를 초기화할 수 없습니다"
            }

        try:
            # 이미지를 base64로 인코딩
            image_data = self._encode_image(image)
            if image_data is None:
                return {
                    "is_match": False,
                    "confidence": 0.0,
                    "reason": "이미지 인코딩 실패"
                }

            prompt = self.build_prompt(feature_description)

            # Gemini API 호출
            response = client.models.generate_content(
                model=self.model_name,
                contents=[
                    {
                        "parts": [
                            {"text": prompt},
                            {
                                "inline_data": {
                                    "mime_type": "image/jpeg",
                                    "data": image_data
                                }
                            }
                        ]
                    }
                ]
            )

            return self._parse_response(response.text)

        except Exception as e:
            return {
                "is_match": False,
                "confidence": 0.0,
                "reason": f"API 호출 실패: {str(e)}"
            }
