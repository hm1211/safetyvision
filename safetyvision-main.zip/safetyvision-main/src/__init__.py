"""Safety Vision - 영상에서 특정 인물 등장 시간대 검색 서비스"""
