"""영상 프레임 추출 서비스"""
from typing import List, Dict, Any
from dataclasses import dataclass


@dataclass
class FrameData:
    """프레임 데이터"""
    timestamp: float
    frame: Any  # numpy array (cv2 frame)


class VideoProcessor:
    """영상에서 프레임을 추출하는 클래스"""

    def __init__(self):
        self._cap = None

    def get_video_info(self, video_path: str) -> Dict[str, Any]:
        """영상 정보를 반환한다

        Args:
            video_path: 영상 파일 경로

        Returns:
            fps, total_frames, duration 정보를 담은 딕셔너리
        """
        try:
            import cv2
            cap = cv2.VideoCapture(video_path)

            if not cap.isOpened():
                return {
                    "fps": 0,
                    "total_frames": 0,
                    "duration": 0,
                    "error": "영상을 열 수 없습니다"
                }

            fps = cap.get(cv2.CAP_PROP_FPS)
            total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            duration = total_frames / fps if fps > 0 else 0

            cap.release()

            return {
                "fps": fps,
                "total_frames": total_frames,
                "duration": duration
            }
        except ImportError:
            # cv2가 없는 경우 (테스트용)
            return {
                "fps": 30,
                "total_frames": 0,
                "duration": 0
            }

    def extract_frames(self, video_path: str, interval_sec: float = 1.0) -> List[Dict[str, Any]]:
        """영상에서 일정 간격으로 프레임을 추출한다

        Args:
            video_path: 영상 파일 경로
            interval_sec: 프레임 추출 간격 (초)

        Returns:
            timestamp와 frame을 담은 딕셔너리 리스트
        """
        frames = []

        try:
            import cv2
            cap = cv2.VideoCapture(video_path)

            if not cap.isOpened():
                return frames

            fps = cap.get(cv2.CAP_PROP_FPS)
            frame_interval = int(fps * interval_sec) if fps > 0 else 1

            frame_count = 0
            while True:
                ret, frame = cap.read()
                if not ret:
                    break

                if frame_count % frame_interval == 0:
                    timestamp = frame_count / fps if fps > 0 else 0
                    frames.append({
                        "timestamp": timestamp,
                        "frame": frame
                    })

                frame_count += 1

            cap.release()

        except ImportError:
            # cv2가 없는 경우 빈 리스트 반환
            pass

        return frames
