"""타임스탬프 병합 서비스"""
from typing import List, Dict


class TimestampMerger:
    """연속된 타임스탬프를 구간으로 병합하는 클래스"""

    def __init__(self, gap_threshold: float = 2.0):
        """
        Args:
            gap_threshold: 이 값보다 큰 간격이 있으면 별도 구간으로 분리 (초)
        """
        self.gap_threshold = gap_threshold

    def merge(self, timestamps: List[float]) -> List[Dict[str, float]]:
        """타임스탬프 리스트를 연속 구간으로 병합한다

        Args:
            timestamps: 정렬된 타임스탬프 리스트 (초 단위)

        Returns:
            병합된 구간 리스트 [{start, end}, ...]
        """
        if not timestamps:
            return []

        # 정렬
        sorted_timestamps = sorted(timestamps)
        ranges = []

        current_start = sorted_timestamps[0]
        current_end = sorted_timestamps[0]

        for i in range(1, len(sorted_timestamps)):
            timestamp = sorted_timestamps[i]

            # 이전 타임스탬프와의 간격 확인
            if timestamp - current_end <= self.gap_threshold:
                # 연속됨 - 구간 확장
                current_end = timestamp
            else:
                # 간격이 큼 - 현재 구간 저장하고 새 구간 시작
                ranges.append({
                    "start": current_start,
                    "end": current_end
                })
                current_start = timestamp
                current_end = timestamp

        # 마지막 구간 저장
        ranges.append({
            "start": current_start,
            "end": current_end
        })

        return ranges

    def format_time(self, seconds: float) -> str:
        """초를 MM:SS 형식으로 변환한다

        Args:
            seconds: 초 단위 시간

        Returns:
            MM:SS 형식의 문자열
        """
        minutes = int(seconds // 60)
        secs = int(seconds % 60)
        return f"{minutes:02d}:{secs:02d}"

    def format_results(self, ranges: List[Dict[str, float]]) -> List[str]:
        """구간 리스트를 읽기 쉬운 문자열로 변환한다

        Args:
            ranges: 병합된 구간 리스트

        Returns:
            "MM:SS - MM:SS" 형식의 문자열 리스트
        """
        formatted = []
        for r in ranges:
            start_str = self.format_time(r["start"])
            end_str = self.format_time(r["end"])
            formatted.append(f"{start_str} - {end_str}")
        return formatted
