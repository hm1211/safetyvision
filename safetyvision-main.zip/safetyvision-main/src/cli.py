"""Safety Vision CLI 데모"""
import os
from typing import List, Optional
from dotenv import load_dotenv

from src.pipeline import SafetyVisionPipeline


def get_supported_extensions() -> List[str]:
    """지원하는 영상 확장자 목록을 반환한다"""
    return [".mp4", ".avi", ".mov", ".mkv", ".wmv", ".flv", ".webm"]


def list_videos(folder_path: str) -> List[str]:
    """폴더 내 영상 파일 목록을 반환한다

    Args:
        folder_path: 검색할 폴더 경로

    Returns:
        영상 파일 경로 리스트
    """
    if not os.path.isdir(folder_path):
        return []

    extensions = get_supported_extensions()
    videos = []

    for filename in os.listdir(folder_path):
        ext = os.path.splitext(filename)[1].lower()
        if ext in extensions:
            videos.append(os.path.join(folder_path, filename))

    return sorted(videos)


def display_menu(videos: List[str]) -> None:
    """영상 선택 메뉴를 표시한다

    Args:
        videos: 영상 파일 경로 리스트
    """
    print("\n" + "=" * 50)
    print("  Safety Vision - 영상 내 인물 검색")
    print("=" * 50)

    if not videos:
        print("\n  영상 파일이 없습니다.")
        return

    print("\n  사용 가능한 영상 목록:\n")
    for i, video in enumerate(videos, 1):
        filename = os.path.basename(video)
        print(f"    [{i}] {filename}")

    print(f"\n    [0] 종료")
    print()


def format_progress(progress: float) -> str:
    """진행률을 문자열로 포맷한다

    Args:
        progress: 0.0 ~ 1.0 사이의 진행률

    Returns:
        포맷된 진행률 문자열
    """
    percentage = int(progress * 100)
    bar_length = 30
    filled = int(bar_length * progress)
    bar = "█" * filled + "░" * (bar_length - filled)
    return f"[{bar}] {percentage}%"


def run_search(video_path: str, feature_description: str) -> None:
    """영상 검색을 실행한다

    Args:
        video_path: 영상 파일 경로
        feature_description: 찾고자 하는 특징 설명
    """
    print(f"\n검색 중: '{feature_description}'")
    print(f"영상: {os.path.basename(video_path)}\n")

    pipeline = SafetyVisionPipeline()

    def progress_callback(progress: float):
        print(f"\r{format_progress(progress)}", end="", flush=True)

    result = pipeline.search(video_path, feature_description, progress_callback)
    print()  # 줄바꿈

    if result["error"]:
        print(f"\n오류: {result['error']}")
        return

    print("\n" + "=" * 50)
    print("  검색 결과")
    print("=" * 50)
    print(f"\n  분석된 프레임: {result['total_frames_analyzed']}")
    print(f"  감지된 인원: {result['persons_detected']}")
    print(f"  매칭된 횟수: {result['matches_found']}")

    print("\n  등장 시간대:")
    for time_range in result["formatted_results"]:
        print(f"    • {time_range}")
    print()


def main():
    """CLI 메인 함수"""
    import sys

    # 스크립트 위치 기준으로 프로젝트 루트 찾기
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)

    # 환경변수 로드 (.env 또는 .env.dev)
    env_path = os.path.join(project_root, ".env")
    env_dev_path = os.path.join(project_root, ".env.dev")
    if os.path.exists(env_path):
        load_dotenv(env_path)
    elif os.path.exists(env_dev_path):
        load_dotenv(env_dev_path)

    # 영상 폴더 설정 (기본값: 프로젝트 루트의 testvideo 하위 폴더)
    if len(sys.argv) > 1:
        video_folder = sys.argv[1]
    else:
        video_folder = os.path.join(project_root, "testvideo")

    # 폴더가 없으면 생성
    if not os.path.exists(video_folder):
        os.makedirs(video_folder)
        print(f"\n'{video_folder}' 폴더를 생성했습니다.")
        print("이 폴더에 영상 파일을 넣고 다시 실행해주세요.")
        return

    while True:
        videos = list_videos(video_folder)
        display_menu(videos)

        if not videos:
            print(f"\n'{video_folder}' 폴더에 영상 파일을 넣고 다시 실행해주세요.")
            break

        try:
            choice = input("  영상 번호를 선택하세요: ").strip()

            if choice == "0":
                print("\n  프로그램을 종료합니다.\n")
                break

            idx = int(choice) - 1
            if 0 <= idx < len(videos):
                selected_video = videos[idx]
                print(f"\n  선택: {os.path.basename(selected_video)}")

                feature = input("\n  찾고자 하는 인물의 특징을 입력하세요: ").strip()
                if feature:
                    run_search(selected_video, feature)

                input("\n  계속하려면 Enter를 누르세요...")
            else:
                print("\n  잘못된 선택입니다.")

        except ValueError:
            print("\n  숫자를 입력해주세요.")
        except KeyboardInterrupt:
            print("\n\n  프로그램을 종료합니다.\n")
            break


if __name__ == "__main__":
    main()
