"""Safety Vision - 영상 내 인물 검색 서비스

사용법:
    python main.py [영상 폴더 경로]

예시:
    python main.py
    python main.py ./my_videos
"""
from src.cli import main

if __name__ == "__main__":
    main()
