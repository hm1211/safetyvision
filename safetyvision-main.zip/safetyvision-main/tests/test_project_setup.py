"""프로젝트 초기 설정 테스트"""
import os


def test_src_directory_exists():
    """src 디렉토리가 존재해야 한다"""
    assert os.path.isdir("src")


def test_src_is_python_package():
    """src가 Python 패키지여야 한다"""
    assert os.path.isfile("src/__init__.py")


def test_tests_directory_exists():
    """tests 디렉토리가 존재해야 한다"""
    assert os.path.isdir("tests")


def test_requirements_has_yolo():
    """requirements.txt에 ultralytics(YOLO)가 있어야 한다"""
    with open("requirements.txt", "r") as f:
        content = f.read()
    assert "ultralytics" in content


def test_requirements_has_opencv():
    """requirements.txt에 opencv가 있어야 한다"""
    with open("requirements.txt", "r") as f:
        content = f.read()
    assert "opencv" in content


def test_requirements_has_gemini():
    """requirements.txt에 google-genai가 있어야 한다"""
    with open("requirements.txt", "r") as f:
        content = f.read()
    assert "google-genai" in content
