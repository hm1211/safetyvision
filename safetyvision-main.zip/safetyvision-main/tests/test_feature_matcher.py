"""Gemini 특징 매칭 서비스 테스트"""
import pytest


class TestFeatureMatcher:
    """FeatureMatcher 클래스 테스트"""

    def test_feature_matcher_class_exists(self):
        """FeatureMatcher 클래스가 존재해야 한다"""
        from src.feature_matcher import FeatureMatcher
        assert FeatureMatcher is not None

    def test_matcher_has_match_method(self):
        """match 메서드가 존재해야 한다"""
        from src.feature_matcher import FeatureMatcher

        matcher = FeatureMatcher()
        assert hasattr(matcher, "match")
        assert callable(matcher.match)

    def test_match_returns_result_dict(self):
        """match는 결과 딕셔너리를 반환해야 한다"""
        from src.feature_matcher import FeatureMatcher

        matcher = FeatureMatcher()
        # 더미 테스트 (이미지 없이)
        result = matcher.match(None, "빨간 모자를 쓴 사람")

        assert isinstance(result, dict)
        assert "is_match" in result
        assert "confidence" in result

    def test_match_with_invalid_image_returns_false(self):
        """유효하지 않은 이미지는 매칭 실패를 반환해야 한다"""
        from src.feature_matcher import FeatureMatcher

        matcher = FeatureMatcher()
        result = matcher.match(None, "빨간 모자를 쓴 사람")

        assert result["is_match"] is False

    def test_build_prompt_returns_string(self):
        """프롬프트 빌드 메서드가 문자열을 반환해야 한다"""
        from src.feature_matcher import FeatureMatcher

        matcher = FeatureMatcher()
        prompt = matcher.build_prompt("빨간 모자를 쓴 사람")

        assert isinstance(prompt, str)
        assert "빨간 모자를 쓴 사람" in prompt
