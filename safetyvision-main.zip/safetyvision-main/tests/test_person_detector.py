"""YOLO 사람 감지 서비스 테스트"""
import pytest


class TestPersonDetector:
    """PersonDetector 클래스 테스트"""

    def test_person_detector_class_exists(self):
        """PersonDetector 클래스가 존재해야 한다"""
        from src.person_detector import PersonDetector
        assert PersonDetector is not None

    def test_detector_has_detect_method(self):
        """detect 메서드가 존재해야 한다"""
        from src.person_detector import PersonDetector

        detector = PersonDetector()
        assert hasattr(detector, "detect")
        assert callable(detector.detect)

    def test_detect_returns_list(self):
        """detect는 리스트를 반환해야 한다"""
        from src.person_detector import PersonDetector

        detector = PersonDetector()
        # 더미 프레임으로 테스트 (None인 경우 빈 리스트 반환)
        result = detector.detect(None)
        assert isinstance(result, list)

    def test_detection_result_structure(self):
        """감지 결과는 bbox와 confidence를 포함해야 한다"""
        from src.person_detector import PersonDetector

        detector = PersonDetector()
        # PersonDetector는 유효한 결과 구조를 정의해야 함
        # 실제 이미지 없이 구조만 확인
        result_schema = detector.get_result_schema()

        assert "bbox" in result_schema
        assert "confidence" in result_schema

    def test_crop_person_returns_image(self):
        """crop_person은 크롭된 이미지를 반환해야 한다"""
        from src.person_detector import PersonDetector

        detector = PersonDetector()
        assert hasattr(detector, "crop_person")
        assert callable(detector.crop_person)
