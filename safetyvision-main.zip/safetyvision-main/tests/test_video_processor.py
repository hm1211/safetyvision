"""영상 프레임 추출 서비스 테스트"""
import pytest


class TestVideoProcessor:
    """VideoProcessor 클래스 테스트"""

    def test_video_processor_class_exists(self):
        """VideoProcessor 클래스가 존재해야 한다"""
        from src.video_processor import VideoProcessor
        assert VideoProcessor is not None

    def test_load_video_returns_video_info(self):
        """영상 로드 시 영상 정보를 반환해야 한다"""
        from src.video_processor import VideoProcessor

        processor = VideoProcessor()
        # 테스트용 더미 영상 경로 (실제 파일 없이 테스트)
        info = processor.get_video_info("test_video.mp4")

        assert "fps" in info
        assert "total_frames" in info
        assert "duration" in info

    def test_extract_frames_returns_list(self):
        """프레임 추출 시 리스트를 반환해야 한다"""
        from src.video_processor import VideoProcessor

        processor = VideoProcessor()
        frames = processor.extract_frames("test_video.mp4", interval_sec=1)

        assert isinstance(frames, list)

    def test_frame_result_contains_timestamp(self):
        """추출된 프레임에는 타임스탬프가 포함되어야 한다"""
        from src.video_processor import VideoProcessor

        processor = VideoProcessor()
        frames = processor.extract_frames("test_video.mp4", interval_sec=1)

        # 프레임이 있다면 타임스탬프가 있어야 함
        if len(frames) > 0:
            assert "timestamp" in frames[0]
            assert "frame" in frames[0]
