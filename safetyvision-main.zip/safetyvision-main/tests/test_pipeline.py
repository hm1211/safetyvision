"""통합 파이프라인 테스트"""
import pytest


class TestSafetyVisionPipeline:
    """SafetyVisionPipeline 클래스 테스트"""

    def test_pipeline_class_exists(self):
        """SafetyVisionPipeline 클래스가 존재해야 한다"""
        from src.pipeline import SafetyVisionPipeline
        assert SafetyVisionPipeline is not None

    def test_pipeline_has_required_components(self):
        """파이프라인은 필수 컴포넌트를 가져야 한다"""
        from src.pipeline import SafetyVisionPipeline

        pipeline = SafetyVisionPipeline()

        assert hasattr(pipeline, "video_processor")
        assert hasattr(pipeline, "person_detector")
        assert hasattr(pipeline, "feature_matcher")
        assert hasattr(pipeline, "timestamp_merger")

    def test_pipeline_has_search_method(self):
        """search 메서드가 존재해야 한다"""
        from src.pipeline import SafetyVisionPipeline

        pipeline = SafetyVisionPipeline()
        assert hasattr(pipeline, "search")
        assert callable(pipeline.search)

    def test_search_returns_result_dict(self):
        """search는 결과 딕셔너리를 반환해야 한다"""
        from src.pipeline import SafetyVisionPipeline

        pipeline = SafetyVisionPipeline()
        # 존재하지 않는 영상으로 테스트
        result = pipeline.search("nonexistent.mp4", "빨간 모자를 쓴 사람")

        assert isinstance(result, dict)
        assert "success" in result
        assert "time_ranges" in result
        assert "formatted_results" in result

    def test_search_with_invalid_video_returns_error(self):
        """유효하지 않은 영상은 실패 결과를 반환해야 한다"""
        from src.pipeline import SafetyVisionPipeline

        pipeline = SafetyVisionPipeline()
        result = pipeline.search("nonexistent.mp4", "빨간 모자를 쓴 사람")

        assert result["success"] is False

    def test_pipeline_has_configurable_interval(self):
        """파이프라인은 프레임 추출 간격을 설정할 수 있어야 한다"""
        from src.pipeline import SafetyVisionPipeline

        pipeline = SafetyVisionPipeline(frame_interval=2.0)
        assert pipeline.frame_interval == 2.0
