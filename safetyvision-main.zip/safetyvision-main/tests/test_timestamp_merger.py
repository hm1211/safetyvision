"""타임스탬프 병합 서비스 테스트"""
import pytest


class TestTimestampMerger:
    """TimestampMerger 클래스 테스트"""

    def test_timestamp_merger_class_exists(self):
        """TimestampMerger 클래스가 존재해야 한다"""
        from src.timestamp_merger import TimestampMerger
        assert TimestampMerger is not None

    def test_merge_returns_list(self):
        """merge는 리스트를 반환해야 한다"""
        from src.timestamp_merger import TimestampMerger

        merger = TimestampMerger()
        result = merger.merge([])
        assert isinstance(result, list)

    def test_merge_single_timestamp(self):
        """단일 타임스탬프는 그대로 반환해야 한다"""
        from src.timestamp_merger import TimestampMerger

        merger = TimestampMerger()
        timestamps = [1.0]
        result = merger.merge(timestamps)

        assert len(result) == 1
        assert result[0]["start"] == 1.0
        assert result[0]["end"] == 1.0

    def test_merge_consecutive_timestamps(self):
        """연속된 타임스탬프는 하나의 구간으로 병합해야 한다"""
        from src.timestamp_merger import TimestampMerger

        merger = TimestampMerger(gap_threshold=2.0)
        timestamps = [1.0, 2.0, 3.0]  # 1초 간격 (gap_threshold 이내)
        result = merger.merge(timestamps)

        assert len(result) == 1
        assert result[0]["start"] == 1.0
        assert result[0]["end"] == 3.0

    def test_merge_non_consecutive_timestamps(self):
        """연속되지 않은 타임스탬프는 별도 구간으로 분리해야 한다"""
        from src.timestamp_merger import TimestampMerger

        merger = TimestampMerger(gap_threshold=2.0)
        timestamps = [1.0, 2.0, 10.0, 11.0]  # 3.0과 10.0 사이 큰 간격
        result = merger.merge(timestamps)

        assert len(result) == 2
        assert result[0]["start"] == 1.0
        assert result[0]["end"] == 2.0
        assert result[1]["start"] == 10.0
        assert result[1]["end"] == 11.0

    def test_format_time_returns_string(self):
        """format_time은 문자열을 반환해야 한다"""
        from src.timestamp_merger import TimestampMerger

        merger = TimestampMerger()
        formatted = merger.format_time(65.5)  # 1분 5.5초

        assert isinstance(formatted, str)
        assert "01:05" in formatted

    def test_format_results_returns_readable_strings(self):
        """format_results는 읽기 쉬운 문자열 리스트를 반환해야 한다"""
        from src.timestamp_merger import TimestampMerger

        merger = TimestampMerger()
        ranges = [{"start": 0.0, "end": 5.0}]
        result = merger.format_results(ranges)

        assert isinstance(result, list)
        assert len(result) == 1
        assert "00:00" in result[0]
