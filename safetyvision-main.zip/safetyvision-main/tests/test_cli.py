"""CLI 데모 테스트"""
import pytest
import os


class TestCLI:
    """CLI 관련 기능 테스트"""

    def test_cli_module_exists(self):
        """CLI 모듈이 존재해야 한다"""
        from src import cli
        assert cli is not None

    def test_list_videos_function_exists(self):
        """list_videos 함수가 존재해야 한다"""
        from src.cli import list_videos
        assert callable(list_videos)

    def test_list_videos_returns_list(self):
        """list_videos는 리스트를 반환해야 한다"""
        from src.cli import list_videos

        # 존재하지 않는 폴더
        result = list_videos("nonexistent_folder")
        assert isinstance(result, list)

    def test_list_videos_filters_video_files(self):
        """list_videos는 영상 파일만 반환해야 한다"""
        from src.cli import get_supported_extensions

        extensions = get_supported_extensions()
        assert ".mp4" in extensions
        assert ".avi" in extensions
        assert ".mov" in extensions

    def test_display_menu_function_exists(self):
        """display_menu 함수가 존재해야 한다"""
        from src.cli import display_menu
        assert callable(display_menu)

    def test_run_search_function_exists(self):
        """run_search 함수가 존재해야 한다"""
        from src.cli import run_search
        assert callable(run_search)

    def test_format_progress_returns_string(self):
        """format_progress는 문자열을 반환해야 한다"""
        from src.cli import format_progress

        result = format_progress(0.5)
        assert isinstance(result, str)
        assert "50" in result  # 50% 포함
